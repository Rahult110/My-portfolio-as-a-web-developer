/** @type {import('tailwindcss').Config} */
module.exports = {
  
    darkMode: 'selector',
    // ...
  
  content: ["./src/index.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

